# EECS767
Building a Haskell based Search Engine

getList :: IO [FilePath]
Fetches a list of all the files in "/Data/" directory.
